"""
Example for demonstrating the fetch capability
==============================================


"""

"""
Download and Process Imagery from the Internet
==============================================


"""

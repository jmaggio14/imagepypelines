"""
Save your processed imagery as a video
======================================


"""

"""
Process your data!
==================

There are a few ways to do this
"""

import imagepypelines as ip
ip.require('image')
